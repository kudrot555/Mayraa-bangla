package com.myraa.bangla

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.OutputStreamWriter
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val navy = Color.rgb(17, 19, 35)
    private val purple = Color.rgb(83, 109, 254)
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val history = JSONArray()
    private val speechRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val masterKey = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            prefs = EncryptedSharedPreferences.create(
                this, "myraa_secure_prefs", masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Toast.makeText(this, "নিরাপদ স্টোরেজ চালু করা যায়নি। অ্যাপ আপডেট/পুনরায় ইনস্টল করে দেখুন।", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("MYRAA", "আসসালামু আলাইকুম! আমি MYRAA বাংলা। নিচে লিখে বা মাইক্রোফোনে কথা বলে প্রশ্ন করুন।", false)
        if (prefs.getString("api_key", null).isNullOrBlank()) showApiSetup()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(navy)
        }
        val title = TextView(this).apply {
            text = "MYRAA বাংলা"
            textSize = 26f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "আপনার বাংলা AI সহকারী"
            textSize = 14f; setTextColor(Color.LTGRAY)
        }
        root.addView(title)
        root.addView(subtitle)
        val topButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val settings = button("API Key সেটিংস") { showApiSetup() }
        topButtons.addView(settings)
        root.addView(topButtons)
        transcript = TextView(this).apply {
            textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12))
            gravity = Gravity.TOP or Gravity.START
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { text = "প্রস্তুত"; textSize = 13f; setTextColor(0xFF9FA8DA.toInt()) }
        root.addView(status)
        input = EditText(this).apply {
            hint = "এখানে বাংলায় লিখুন…"; textSize = 16f; setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY); setSingleLine(false); maxLines = 3
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(0xFF25283D.toInt(), 14)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(button("🎙 কথা বলুন") { startSpeech() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(button("পাঠান") { sendMessage() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        root.addView(row)
        setContentView(root)
    }

    private fun showApiSetup() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val info = TextView(this).apply {
            text = "Google AI Studio থেকে Gemini API key তৈরি করুন। কীটি এই ডিভাইসে Android Keystore-ভিত্তিক এনক্রিপ্টেড স্টোরেজে রাখা হবে।"
            textSize = 15f
        }
        val keyInput = EditText(this).apply {
            hint = "Gemini API key"; inputType = 0x00000081; setSingleLine(true)
            setText(prefs.getString("api_key", "") ?: "")
        }
        box.addView(info); box.addView(keyInput)
        AlertDialogBuilder(this).show(box) {
            val key = keyInput.text.toString().trim()
            if (key.isNotEmpty()) {
                prefs.edit().putString("api_key", key).apply()
                Toast.makeText(this, "API key নিরাপদ স্টোরেজে সংরক্ষিত হয়েছে", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val key = prefs.getString("api_key", null)
        if (key.isNullOrBlank()) { showApiSetup(); return }
        addMessage("আপনি", prompt, true)
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        status.text = "উত্তর তৈরি হচ্ছে…"
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        executor.execute {
            try {
                val answer = askGemini(key, history)
                runOnUiThread {
                    history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", answer))))
                    addMessage("MYRAA", answer, false)
                    status.text = "প্রস্তুত"
                    speak(answer)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "সমস্যা হয়েছে"
                    addMessage("ত্রুটি", "উত্তর পাওয়া যায়নি: ${e.message ?: "নেটওয়ার্ক বা API key পরীক্ষা করুন"}", false)
                }
            }
        }
    }

    private fun askGemini(key: String, contents: JSONArray): String {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" +
            URLEncoder.encode(key, "UTF-8")
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
        }
        val body = JSONObject().put("systemInstruction", JSONObject().put("parts",
            JSONArray().put(JSONObject().put("text", "তুমি MYRAA, একজন সহায়ক বাংলা AI সহকারী। স্বাভাবিক, পরিষ্কার বাংলায় উত্তর দাও।")))
        ).put("contents", contents)
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        val json = JSONObject(response)
        if (code !in 200..299) {
            val msg = json.optJSONObject("error")?.optString("message") ?: "HTTP $code"
            throw Exception(msg.take(220))
        }
        return json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun startSpeech() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1002)
            return
        }
        launchSpeech()
    }
    private fun launchSpeech() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় বলুন")
            }
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) {
            Toast.makeText(this, "এই ফোনে Speech Recognition পাওয়া যাচ্ছে না।", Toast.LENGTH_LONG).show()
        }
    }
    @Deprecated("Deprecated by Android; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!result.isNullOrBlank()) { input.setText(result); sendMessage() }
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1002 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) launchSpeech()
        else if (requestCode == 1002) Toast.makeText(this, "কথা শুনতে মাইক্রোফোন অনুমতি দরকার।", Toast.LENGTH_LONG).show()
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            ttsReady = true
            val result = tts?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                tts?.setLanguage(Locale("bn", "IN"))
        }
    }
    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myraa-answer")
    }
    private fun addMessage(who: String, text: String, user: Boolean) {
        val existing = transcript.text.toString()
        transcript.text = (if (existing.isBlank()) "" else "$existing\n\n") + "$who:\n$text"
    }
    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
            background = rounded(purple, 14); setOnClickListener { action() }
        }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); executor.shutdownNow()
        super.onDestroy()
    }
}

/** Minimal dialog wrapper to keep the key setup screen simple. */
private class AlertDialogBuilder(private val activity: Activity) {
    fun show(content: View, save: () -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setTitle("Gemini API সেটআপ")
            .setView(content)
            .setPositiveButton("সংরক্ষণ") { _, _ -> save() }
            .setNegativeButton("পরে করব", null)
            .show()
    }
}
