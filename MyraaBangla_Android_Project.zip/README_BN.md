# MYRAA বাংলা — Android starter project

এই প্রজেক্টে আছে:
- বাংলা AI chat (Gemini API)
- Android Speech Recognizer দিয়ে বাংলা voice input
- Android TextToSpeech দিয়ে উত্তর পড়ে শোনানো
- API key এনক্রিপ্টেড SharedPreferences-এ রাখা (Android Keystore-ভিত্তিক)
- API key সেটআপ ডায়ালগ

## কী লাগবে
- Android Studio (সাম্প্রতিক স্থিতিশীল সংস্করণ)
- JDK 17
- Android SDK Platform 35
- ইন্টারনেট সংযোগ
- Google AI Studio থেকে আপনার নিজস্ব Gemini API key

## APK তৈরি
1. ZIP ফাইলটি Extract করুন।
2. Android Studio-তে `MyraaBangla` ফোল্ডার খুলুন।
3. Gradle sync সম্পূর্ণ হতে দিন।
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` নির্বাচন করুন।
5. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## API key যোগ করা
অ্যাপ চালু করে `API Key সেটিংস` চাপুন এবং নিজের Gemini API key পেস্ট করে সংরক্ষণ করুন। API key অ্যাপের সোর্স কোডে রাখা হয়নি। HTTPS ব্যবহার করা হয়েছে। API key ফোনে Android Keystore-ভিত্তিক encrypted preferences-এ রাখা হয়।

## গুরুত্বপূর্ণ নিরাপত্তা সীমা
- মোবাইল অ্যাপে সরাসরি API key রাখলে ডিভাইসের মালিকের কাছ থেকে সেটি সম্পূর্ণ গোপন রাখা যায় না; এটি encrypted at rest, কিন্তু অ্যাপটি ব্যবহার করে এমন ব্যক্তির কাছ থেকে নিখুঁতভাবে সুরক্ষিত নয়।
- পাবলিক/বাণিজ্যিক বিতরণের জন্য সুপারিশ: নিজস্ব backend/proxy ব্যবহার করুন, API key server-side রাখুন, quota ও rate limit দিন।
- Google AI Studio-তে billing/quota ও model availability আপনার অ্যাকাউন্টের ওপর নির্ভর করে।
- বাংলা speech recognition এবং Text-to-Speech-এর মান ডিভাইসের speech service ও ইনস্টল করা ভাষা-ডেটার ওপর নির্ভরশীল।
- এটি একটি starter project; বাস্তব ফোনে পরীক্ষা, API quota যাচাই, এবং প্রয়োজনে model endpoint আপডেট করা দরকার।
